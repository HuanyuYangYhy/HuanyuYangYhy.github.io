function stopflag = StoppingCriteria(Node,U,icrm)
stopflag = (-U(121*3-2))>12;